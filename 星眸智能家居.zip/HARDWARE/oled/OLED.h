#ifndef __OLED_H
#define __OLED_H

uint8_t Display_State=0x06;//OLED�����֣���0λ������ɫ��ת����1λ�������ֶ�λ��ʽ��


void OLED_Init(void);
void OLED_Clear(void);
void SetCursor(uint8_t X,uint8_t Y);
void OLED_Send_Command(uint8_t Command);
void OLED_Send_Data(uint8_t Data);
void OLED_ReverseCharColor(FunctionalState NewState);


void OLED_ShowCharacters(uint8_t Row,uint16_t Column,uint8_t Serial_Number);
void OLED_ShowChar(uint8_t Row,uint16_t Column,uint8_t Serial_Number);

void OLED_DisplayChar(uint8_t Row,uint16_t Column,uint8_t Char);
void OLED_DisplayNum(uint8_t Row,uint16_t Column,uint32_t Num,uint8_t length);
void OLED_DisplayDecimal(uint8_t Row,uint16_t Column,uint32_t DecimalNum,uint8_t length);

void OLED_DisplayString(uint8_t Row,uint16_t Column,char *String);//��ʾ�ַ���
void OLED_DisplayHexNum(uint8_t Row,uint8_t Column,uint32_t HexNum,uint8_t length);
void OLED_DisplayBinNum(uint8_t Row,uint8_t Column,uint16_t BinNum,uint8_t length);
void OLED_DisplaySignNum(uint8_t Row,uint16_t Column,int32_t Num,uint8_t length);
void OLED_DisplayFloat(uint8_t Row,uint16_t Column,float Num,uint8_t Integerlength,uint8_t Decimallength);//��ʾ������

void OLED_DisplayPicture(void);

#endif









