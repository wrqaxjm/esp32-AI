#include "stm32f10x.h"
#include "OLED_Font.h"
#include "Delay.h"

#define OLED_SCL(x) GPIO_WriteBit(GPIOB,GPIO_Pin_8,(BitAction)(x))
#define IIC_SCL GPIO_Pin_8
#define OLED_SDA(x) GPIO_WriteBit(GPIOB,GPIO_Pin_9,(BitAction)(x))
#define IIC_SDA GPIO_Pin_9

/****
	*@brief 定义一个显示控制字；
	Display_State[0]：第0位控制文字颜色是否反转，1表示开启文字颜色反转
	Display_State[1]：第1位控制字符定位方式，1表示 列坐标 按字符长宽尺寸定位，0表示 列坐标 按照像素点进行定位
	Display_State[2]：该位默认为1
	*/




/****
	*@brief 让输入的字符颜色反转
	*@parameter NewState：是否要开启字符颜色反转 
  *   This parameter can be: ENABLE or DISABLE.
	*@ReturnValue 无
	*/
void OLED_ReverseCharColor(FunctionalState NewState)
{
	assert_param(IS_FUNCTIONAL_STATE(NewState));
	if(NewState != DISABLE)
	{
		Display_State|=0x01;
	}
	else 
	{
		Display_State&=(~0x01);
	}	
}


/****
	*@brief 初始化IIC端口
	*@parameter 无
	*@ReturnValue 无
	*/
void Prot_Init_Output(void)
{GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
    
    GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Pin=IIC_SCL | IIC_SDA;
    GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
    GPIO_Init(GPIOB,&GPIO_InitStructure);

}

/****
	*@brief 将SDA初始化为上拉输入，接收应答信号
	*@parameter 无
	*@ReturnValue 无
	*/
void SDA_Init_Input(void)
{GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
    
    GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Pin=IIC_SDA;
    GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
    GPIO_Init(GPIOB,&GPIO_InitStructure);
}

/****
	*@brief IIC开始
	*@parameter 无
	*@ReturnValue 无
	*/
void IIC_Sart(void)
{
    OLED_SCL(1);
    OLED_SDA(1);
    OLED_SDA(0);
    OLED_SCL(0);

}
/****
	*@brief IIC结束
	*@parameter 无
	*@ReturnValue 无
	*/
void IIC_Stop()
{

    OLED_SDA(0);
    OLED_SCL(1);
    OLED_SDA(1);
}
/****
	*@brief 主机向IIC发送一个字节
	*@parameter Byte：要发送的字节
	*@ReturnValue ACK_Plag：从机应答信号，ACK_Plag=1表示收到从机应答，否则表示从机无应答
	*/
uint8_t IIC_SendByte(uint8_t Byte)
{
    uint8_t i,ACK_Plag=0;
    for(i=0; i<8; i++)
    {
        if(Byte&(0x80>>i))
        {
            OLED_SDA(1);
        } else
        {
            OLED_SDA(0);
        }
        OLED_SCL(1);

        OLED_SCL(0);
    }
    SDA_Init_Input();//将IO初始化为输入模式

    OLED_SCL(1);
    if(GPIO_ReadInputDataBit(GPIOB,IIC_SDA)==0)// 判断sda状态，从机将SDA拉低表示应答
    {
        ACK_Plag=1;
    }

    OLED_SCL(0);
    Prot_Init_Output();
    return ACK_Plag;
}


/****
	*@brief 发送显示数据
	*@parameter Data：发送到GDDRAM中的显示数据
	*@ReturnValue 无
	*/
void OLED_Send_Data(uint8_t Data)
{
    IIC_Sart();
    IIC_SendByte(0x78);
    IIC_SendByte(0x40);
    IIC_SendByte(Data);
    IIC_Stop();
}
/****
	*@brief 发送命令
	*@parameter Command 要发送的命令
	*@ReturnValue 无
	*/
void OLED_Send_Command(uint8_t Command)
{
    IIC_Sart();
    IIC_SendByte(0x78);
    IIC_SendByte(0x00);
    IIC_SendByte(Command);
    IIC_Stop();
}
/****
	*@brief 光标设置函数
	*@parameter X ：设置列坐标 0-127
	*@parameter Y ：设置页坐标 0-7
	*@ReturnValue 无
	*/

void SetCursor(uint8_t X,uint8_t Y)
{
    OLED_Send_Command(0xB0 | Y);
    OLED_Send_Command(0x10 | (0xF0 & X)>>4);
    OLED_Send_Command(0x00 | (0x0F & X));

}


/****
	*@brief 清屏函数
	*@parameter 无
	*@ReturnValue 无
	*/
void OLED_Clear(void)
{
    uint8_t i,j;
    for(i=0; i<8; i++)
    {
        for(j=0; j<128; j++)
        {
            SetCursor(j,i);
            OLED_Send_Data(0x00);
        }
    }
}


/****
	*@brief 初始化OLED屏幕（简单初始化方式：开启充电泵和显示，其它主要寄存器能够自动赋予默认值）
	*@parameter 无
	*@ReturnValue 无
	*/
void OLED_Init(void)
{
    Delay_ms(10);
    Prot_Init_Output();


    OLED_Send_Command(0xAE);// 关闭显示

    OLED_Send_Command(0xD5);// 设置时钟分频率
    OLED_Send_Command(0xF0);//高四位设置振荡器频率，低四位设置分频后的屏幕显示频率，默认为0x80


    OLED_Send_Command(0xA8);// 设置多路复用率，默认为0x3F
    OLED_Send_Command(0x3F);

    OLED_Send_Command(0xD3);// 设置垂直偏移，默认为零
    OLED_Send_Command(0x00);

    OLED_Send_Command(0x40);// 设置起始行，范围（0x40-0x7f）

    OLED_Send_Command(0xA1);// 设置段重映射，默认为0xA0，影响左右扫描方向

    OLED_Send_Command(0xC8);// 设置COM引脚扫描方向，影响上下扫描方向

    OLED_Send_Command(0xDA);// 配置COM端口
    OLED_Send_Command(0x12);

    OLED_Send_Command(0x81);// 设置对比度
    OLED_Send_Command(0x3F);


    OLED_Send_Command(0xd9);//设置预充电周期
    OLED_Send_Command(0x33);// 默认为0x22

    OLED_Send_Command(0xDB);// 设置Vcomh取消选择级别
    OLED_Send_Command(0x30);

    OLED_Send_Command(0xA4);// 0xA4显示整个GDDRAM中的数据；0xA5只是打开显示，不显示GDDRAM中的数据

    OLED_Send_Command(0xA6);//0xA6设置正常显示，0xA7颜色反相显示

    OLED_Send_Command(0x8D);//  设置充电泵
    OLED_Send_Command(0x14);// 0x14开启充电泵，0x10关闭充电泵

    OLED_Clear();//清空屏幕

    OLED_Send_Command(0xAF);//打开显示


}

/****
	*@brief 汉字显示函数
	*@parameter Row：所显示文字的行坐标；（字符定位模式下，Row范围是1~4）
	*@parameter Column：所显示文字的列坐标：（字符定位模式下，Column范围是1~16）
	*@parameter Serial_Number：对应汉字在OLED_16x16_Characters中的序号
	*@ReturnValue 无
	*/
void OLED_ShowCharacters(uint8_t Row,uint16_t Column,uint8_t Serial_Number)
{
    uint8_t i,j;
    Serial_Number=(Serial_Number-1)*4;

    //****************************显示上半页************************************************************//
    if(Display_State&0x02)//Display_State[1]为1表示 列坐标 采用字符定位
    {
        if(Display_State&0x04)//Display_State[2]为1表示 行坐标 采用字符定位
        {
            Column%=16;// 防止Column超出范围
            Row%=5;// 防止Row超出范围
            Row-=1;
            Row=(Row*2);// 将Row转化为对应的页数
            SetCursor((Column-1)*16,Row);
        }
    } else //Display_State[1]为0表示 列坐标 采用像素定位
    {
        if(Display_State&0x04)//Display_State[2]为1表示 行坐标 采用字符定位
        {
            Column%=112;// 防止Column超出范围
            Row%=5;// 防止Row超出范围
            Row-=1;
            Row=(Row*2);// 将Row转化为对应的页数
            SetCursor((Column-1),Row);
        }
    }
//******************************************///
    for(i=0; i<2; i++)
    {
        for(j=0; j<8; j++)
        {
            if(Display_State&0x01)// 判断最低位状态，最低位为1则开启字符颜色反转
            {
                OLED_Send_Data(~OLED_16x16_Characters[i+Serial_Number][j]);
            } else
            {
                OLED_Send_Data(OLED_16x16_Characters[i+Serial_Number][j]);
            }

        }
    }
//***************************显示下半页************************************************************//
    if(Display_State&0x02)//Display_State[1]为1表示 列坐标 采用字符定位
    {
        if(Display_State&0x04)//Display_State[2]为1表示 行坐标 采用字符定位
        {
            Column%=16;
            SetCursor((Column-1)*16,Row+1);
        }

    } else//Display_State[1]为0表示 列坐标 采用像素定位
    {
        if(Display_State&0x04)//Display_State[2]为1表示 行坐标 采用字符定位
        {
            Column%=112;
            SetCursor((Column-1),Row+1);
        }
    }

    for(i=0; i<2; i++)
    {
        for(j=0; j<8; j++)
        {
            if(Display_State&0x01)// 判断最低位状态，最低位为1则开启字符颜色反转
            {
                OLED_Send_Data(~OLED_16x16_Characters[i+Serial_Number+2][j]);
            } else
            {
                OLED_Send_Data(OLED_16x16_Characters[i+Serial_Number+2][j]);
            }
        }
    }

}
/****
	*@brief OLED显示OLED_8x16_Number数组中的一个符号(genju)
	*@parameter Row：所显示文字的行坐标；（字符定位模式下，Row范围是1~4）
	*@parameter Column：所显示文字的列坐标：（字符定位模式下，Column范围是1~16）
	*@parameter Serial_Number：对应汉字在OLED_16x16_Characters中的序号
	*@ReturnValue 无
	*/
void OLED_ShowChar(uint8_t Row,uint16_t Column,uint8_t Serial_Number)
{
    uint8_t j;
    Serial_Number=(Serial_Number)*2;// 让Serial_Number对应数组中的字符顺序

    //****************************显示上半页************************************************************//
    if(Display_State&0x02)//Display_State[1]为1表示 列坐标 采用字符定位
    {
        if(Display_State&0x04)//Display_State[2]为1表示 行坐标 采用字符定位
        {
            Column%=16;// 防止Column超出范围
            Row%=5;// 防止Row超出范围
            Row-=1;
            Row=(Row*2);// 将Row转化为对应的页数
            SetCursor((Column-1)*8,Row);
        }
    } else //Display_State[1]为0表示 列坐标 采用像素定位
    {
        if(Display_State&0x04)//Display_State[2]为1表示 行坐标 采用字符定位
        {
            Column%=112;// 防止Column超出范围
            Row%=5;// 防止Row超出范围
            Row-=1;
            Row=(Row*2);// 将Row转化为对应的页数
            SetCursor((Column-1),Row);
        }
    }
//******************************************///
    for(j=0; j<8; j++)
    {
        if(Display_State&0x01)// 判断最低位状态，最低位为1则开启字符颜色反转
        {
            OLED_Send_Data(~OLED_8x16_Number[Serial_Number][j]);
        } else
        {
            OLED_Send_Data(OLED_8x16_Number[Serial_Number][j]);
        }

    }
//***************************显示下半页************************************************************//
    if(Display_State&0x02)//Display_State[1]为1表示 列坐标 采用字符定位
    {
        if(Display_State&0x04)//Display_State[2]为1表示 行坐标 采用字符定位
        {
            Column%=16;
            SetCursor((Column-1)*8,Row+1);
        }

    } else//Display_State[1]为0表示 列坐标 采用像素定位
    {
        if(Display_State&0x04)//Display_State[2]为1表示 行坐标 采用字符定位
        {
            Column%=112;
            SetCursor((Column-1),Row+1);
        }
    }
    for(j=0; j<8; j++)
    {
        if(Display_State&0x01)// 判断最低位状态，最低位为1则开启字符颜色反转
        {
            OLED_Send_Data(~OLED_8x16_Number[Serial_Number+1][j]);
        } else
        {
            OLED_Send_Data(OLED_8x16_Number[Serial_Number+1][j]);
        }
    }
}
/****
	*@brief 显示单个ASCII字符
	*@parameter Row：所显示文字的行坐标；Row范围是1~4（行只能使用像素定位）
	*@parameter Column：所显示文字的列坐标：（字符定位模式下，Column范围是1~16）（像素定位模式Column范围为1-112）
	*@parameter Char：所显示的ASCII字符
	*@ReturnValue 无
	*/
void OLED_DisplayChar(uint8_t Row,uint16_t Column,uint8_t Char)
{
    Char=Char-32;
    OLED_ShowChar(Row,Column,Char);
}
/****
	*@brief 显示无符号整数范围：0-（2^32-1）
	*@parameter Row：所显示文字的行坐标；Row范围是1~4（行只能使用像素定位）
	*@parameter Column：所显示文字的列坐标：（字符定位模式下，Column范围是1~16）（像素定位模式Column范围为1-112）
	*@ReturnValue 无
	*/
void OLED_DisplayNum(uint8_t Row,uint16_t Column,uint32_t Num,uint8_t length)
{
    uint8_t Tem[11];
    uint8_t i=0;
    do {
        i++;
        Tem[i]=Num%10;
    } while(Num/=10);// 这个循环用于数出Num中有几个数字
    for(; length>i; length--)
    {
        OLED_DisplayChar(Row,Column,'0');
        Column++;
    }
    do {
        OLED_DisplayChar(Row,Column,Tem[i]+'0');
        Column++;
        i--;
    } while(i);

}
/****
	*@brief 显示字符串（每行最多可以显示16个字符）
	*@parameter Row：所显示文字的行坐标；Row范围是1~4（行只能使用像素定位）
	*@parameter Column：所显示文字的列坐标：（字符定位模式下，Column范围是1~16）（像素定位模式Column范围为1-112）
	*@ReturnValue 无
	*/
void OLED_DisplayString(uint8_t Row,uint8_t Column,char *String)
{
    uint8_t i=0;// 定义遍历所使用的变量
    do {
        OLED_DisplayChar(Row,Column,String[i]);
        i++;
        Column++;
        if(String[i]=='\0')break;// 检测到字符串中的结束符号
    } while(i);
}

/****
	*@brief 显示十六进制数据
	*@parameter Row：所显示文字的行坐标；Row范围是1~4（行只能使用像素定位）
	*@parameter Column：所显示文字的列坐标：（字符定位模式下，Column范围是1~16）（像素定位模式Column范围为1-112）
	*@parameter HexNum：需要显示的十六进制数据HexNum范围（0x00000000~0xFFFFFFFF）
	*@ReturnValue 无
	*/

void OLED_DisplayHexNum(uint8_t Row,uint8_t Column,uint32_t HexNum,uint8_t length)
{
    uint8_t Tem[9];
    uint8_t i=0;

    do {
        i++;
        Tem[i]=HexNum%16;
    }
    while(HexNum/=16);

    for(; length>i; length--)
    {
        OLED_DisplayChar(Row,Column,'0');
        Column++;
    }
    do {
        if(Tem[i]+'0'<='9')
        {
            OLED_DisplayChar(Row,Column,Tem[i]+'0');
        } else
        {
            OLED_DisplayChar(Row,Column,Tem[i]+'0'+7);
        }

        Column++;
        i--;
    } while(i);
}
/****
	*@brief 显示二进制数据
	*@parameter Row：所显示文字的行坐标；Row范围是1~4（行只能使用像素定位）
	*@parameter Column：所显示文字的列坐标：（字符定位模式下，Column范围是1~16）（像素定位模式Column范围为1-112）
	*@parameter BinNum：需要显示的二进制数据，范围是（0x0000~0xFFFF）
	*@ReturnValue 无
	*/
void OLED_DisplayBinNum(uint8_t Row,uint8_t Column,uint16_t BinNum,uint8_t length)
{
    uint8_t Tem[18];
    uint8_t i=0;

    do {
        i++;
        Tem[i]=BinNum%2;// 将BinNum对2取余
    }
    while(BinNum/=2);// 将BinNum缩小二倍
    for(; length>i; length--)
    {
        OLED_DisplayChar(Row,Column,'0');
        Column++;
    }
    do {
        OLED_DisplayChar(Row,Column,Tem[i]+'0');
        Column++;
        i--;
    } while(i);
}
/****
	*@brief 根据OLED_Picture数组中的数据显示图片
	*@parameter 无
	*@ReturnValue 无
	*/
void OLED_DisplayPicture(void)
{
    uint8_t i=0,j=0,k;

    for(i=0; i<8; i++) // 遍历8页
    {
        SetCursor(0,i);
        for(j=0; j<16; j++) // 遍历16x8个字节数据，铺满一页
        {
            for(k=0; k<8; k++)
            {
                OLED_Send_Data(OLED_Picture[j+(16*i)][k]);
            }

        }
    }
}
/****
	*@brief OLED显示有符号数
	*@parameter Row：所显示文字的行坐标；Row范围是1~4（行只能使用像素定位）
	*@parameter Column：所显示文字的列坐标：（字符定位模式下，Column范围是1~16）（像素定位模式Column范围为1-112）
	*@parameter Num：显示范围(-2147483648~2147483647)
	*@ReturnValue 无
	*/
void OLED_DisplaySignNum(uint8_t Row,uint8_t Column,int32_t Num,uint8_t length)
{
    uint8_t Tem[11];
    uint8_t i=0,Sign=0;

    Sign=(Num&0x80000000)>>31;// 取出符号位（最高位），负数的符号位（最高位）为1；
    if(Sign)// 判断Num为负数
    {
        Num=~Num;// 将负数按位取反（符号位也取反，抛弃最高位的符号位）
        Num++;// 按位取反后加1，获得负数的绝对值
    }
    do {
        i++;
        Tem[i]=Num%10;
    }
    while(Num/=10);

    if(Sign)
    {
        OLED_DisplayChar(Row,Column,'-');
    } else
    {
        OLED_DisplayChar(Row,Column,'+');
    }
    Column++;// 由于正负号占据了一个空格，故偏移一个位置
    for(; length>i; length--)
    {
        OLED_DisplayChar(Row,Column,'0');
        Column++;
    }
    do {
        OLED_DisplayChar(Row,Column,Tem[i]+'0');
        Column++;
        i--;
    } while(i);
}
/****
	*@brief 将整数DecimalNum按小数后的数字形式显示，例如DecimalNum=123，length=4，则显示1230
	*@parameter
	*@ReturnValue
	*/
void OLED_DisplayDecimal(uint8_t Row,uint8_t Column,uint32_t DecimalNum,uint8_t length)
{
    uint8_t Tem[11];
    uint8_t i=0,j;
    do {
        i++;
        Tem[i]=DecimalNum%10;
    } while(DecimalNum/=10);
    j=i;
    do {
        OLED_DisplayChar(Row,Column,Tem[i]+'0');
        i--;
        Column++;
    } while(i);

    for(; length>j; length--)
    {
        OLED_DisplayChar(Row,Column,'0');
        Column++;
    }
}
/****
	*@brief 显示float类型的数据
	*@parameter Row：显示所在行
	*@parameter Column：显示所在列
	*@parameter FloatNum：要显示的float类型数据
	*@parameter Integerlength：所显示的float类型整数部分长度
	*@parameter Decimallength：所显示的float类型小部分长度
	*@ReturnValue 无
	*/
void OLED_DisplayFloat(uint8_t Row,uint8_t Column,float FloatNum,uint8_t Integerlength,uint8_t Decimallength)
{
    float Tem_1;
    uint8_t Decimallength_tem=Decimallength;
    if((int32_t)FloatNum>=0)
    {
        Tem_1=FloatNum-(int32_t)FloatNum;
    } else
    {
        Tem_1=(int32_t)FloatNum-FloatNum;//@1 只能处理正小数，此处将Num的小数部分变为正小数
    }

    for(; Decimallength>0; Decimallength--) // @1
    {
        Tem_1*=10;
    }
    OLED_DisplaySignNum(Row,Column,(int32_t)FloatNum,Integerlength);
    OLED_DisplayChar(Row,Column+Integerlength+1,'.');
    OLED_DisplayDecimal(Row,Column+Integerlength+2,Tem_1,Decimallength_tem);
}
