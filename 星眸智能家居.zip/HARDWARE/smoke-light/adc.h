#ifndef __ADC_H
#define	__ADC_H


#include "stm32f10x.h"
#include "Delay.h"

#define    ADC_APBxClock_FUN             RCC_APB2PeriphClockCmd

#define    ADC_CLK1                       RCC_APB2Periph_ADC1
#define    ADC_CLK2                       RCC_APB2Periph_ADC2


#define    ADC_GPIO_APBxClock_FUN        RCC_APB2PeriphClockCmd
#define    ADC_GPIO_CLK                  RCC_APB2Periph_GPIOA  
#define    ADC_PORT                      GPIOA
#define    ADC_PIN_0                       GPIO_Pin_0
#define    ADC_PIN_5                       GPIO_Pin_5

#define    ADC_CHANNEL_0                   ADC_Channel_0
#define    ADC_CHANNEL_5                   ADC_Channel_5

#define    ADC_IRQ                       ADC1_2_IRQn
#define    ADC_IRQHandler                ADC1_2_IRQHandler


void ADC1_Init(void);
float Get_ADC1(void);


void ADC2_Init(void);
float Get_ADC2(void);
//static void ADC_NVIC_Config(void);
#endif

