#ifndef __DS18B20_DEVICEDATA_H
#define __DS18B20_DEVICEDATA_H




#define DS18B20_Pin 			GPIO_Pin_15//DS18B20所在的GPIO引脚
#define DS18B20_Port 			GPIOB//DS18B20所在的GPIO端口
#define DS18B20_PortRccClock 	RCC_APB2Periph_GPIOB//DS18B20所在的GPIO端口的时钟

#define DS18B20_SEARCH_ROM 		 0xF0//搜索ROM
#define DS18B20_READ_ROM   		 0x33//读取ROM
#define DS18B20_MATCH_ROM 		 0x55//匹配ROM
#define DS18B20_SKIP_ROM  		 0xCC//跳过ROM
#define DS18B20_ALARM_SEARCH 	 0xEC//搜索警报
#define DS18B20_CONVERT_T 		 0x44//温度转换
#define DS18B20_WRITE_SCRATCHPAD 0x4E//写暂存器
#define DS18B20_READ_SCRATCHPAD  0xBE//读暂存器
#define DS18B20_COPY_SCRATCHPAD  0x48//将数据从暂存器保存到EEPROM
#define DS18B20_RECALL_E2		 0xB8//将数据从EEPROM中取回到暂存器
#define DS18B20_POWER_SUPPLY     0xB4//获取供电方式
#define DS18B20_Accuracy_12Bit   0x7F//12位转换精度
#define DS18B20_Accuracy_11Bit   0x5F//11位转换精度
#define DS18B20_Accuracy_10Bit   0x3F//10位转换精度
#define DS18B20_Accuracy_9Bit    0x1F//9位转换精度




const uint8_t DS18B20_RomTab[][8]=//DS18B20ROM地址
	{
	0x28,0xFF,0x37,0x3A,0x53,0x18,0x01,0x95, //*第一个18B20*//
	0x28,0xFF,0x2C,0x9D,0x31,0x18,0x02,0xBE,  //*第二个18B20*//
	0x28,0x2E,0x36,0x81,0xE3,0xE1,0x3C,0x7A,  //*第三个18B20*//   				/
	0x28,0x36,0xD2,0x81,0xE3,0xE1,0x3C,0x45,
	0x28,0x69,0x65,0x81,0xE3,0xE1,0x3C,0x51,	
	0x28,0xC8,0x2C,0x95,0xF0,0x01,0x3C,0xCD,									//
	0x28,0xAF,0XF4,0X48,0XF6,0XBE,0X3C,0XBC,
	0X28,0XFF,0XFC,0XB3,0X53,0X18,0X01,0X8D,									///
	0X28,0XA6,0XE5,0X81,0XE3,0XE1,0X3C,0X21, //*第九个18B20*//
		
	};//*ds18B20编号*//

								
								
#endif




