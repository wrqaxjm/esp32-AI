#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "DS18B20.h"
#include "DS18B20_DEVICEDATA.h"
#include <stdbool.h>


uint8_t DS18B20_ExistSign;//DS18B20存在标志
uint8_t DS18B20_Tem_Integer;//温度数据整数部分
uint8_t DS18B20_Tem_Decimal;//温度小数部分（小数点后一位的数字）
uint8_t DS18B20_Tem_Sign = 0; //温度正负标志位
uint8_t TemData[9] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
uint8_t DS18B20Rom[8]={0, 0, 0, 0, 0, 0, 0, 0};
uint8_t Ds18B20Group_Deviceloaction;//DS18B20在DS18B20_RomTab数组中的行坐标
float DS18B20_FloatTemData;








void DS18B20_PinInit(void)//初始化DS18B20数据引脚
{GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(DS18B20_PortRccClock, ENABLE);

    
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD; //开漏输出模式，需要外界上拉电阻，ds18B20引线越长，电阻应当越小
    GPIO_InitStructure.GPIO_Pin = DS18B20_Pin;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(DS18B20_Port, &GPIO_InitStructure);
    GPIO_WriteBit(DS18B20_Port, DS18B20_Pin, Bit_SET);
	DS18B20_Reset();
}
/****
	*@brief 复位DS18B20
	*@parameter 无
	*@ReturnValue 无
	*/
void DS18B20_Reset(void)
{
    GPIO_WriteBit(DS18B20_Port, DS18B20_Pin, Bit_RESET);
    Delay_us(500);
    GPIO_WriteBit(DS18B20_Port, DS18B20_Pin, Bit_SET);
    Delay_us(70);
    if(GPIO_ReadInputDataBit(DS18B20_Port, DS18B20_Pin) == 0) //获取DS18B20存在标志位
    {
        DS18B20_ExistSign = 1;
    }
    else
    {
        DS18B20_ExistSign = 0;
    }

    Delay_us(400);
}
/****
	*@brief DS18B20发送一位数据
	*@parameter bit：0或1
	*@ReturnValue 无
	*/
void DS18B20_SendBit(uint8_t bit)
{
//    if(DS18B20_ExistSign == 1) //存在18B20
//    {
        GPIO_WriteBit(DS18B20_Port, DS18B20_Pin, Bit_RESET); //拉低总线
        Delay_us(10);//DS18B20写时序之前要先将总线拉低，再释放
        GPIO_WriteBit(DS18B20_Port, DS18B20_Pin, (BitAction)(bit)); //发送数据
        Delay_us(80);
        GPIO_WriteBit(DS18B20_Port, DS18B20_Pin, Bit_SET); //释放总线
//    }
}
/****
	*@brief ds18B20发送一字节数据
	*@parameter Data：DS18B20所发送的数据
	*@ReturnValue 无
	*/
void DS18B20_SendData(uint8_t Data)
{
    uint8_t i = 0;
    if(DS18B20_ExistSign == 1) //存在18B20
    {
        for(i = 0; i < 8; i++)
        {
            DS18B20_SendBit(Data & (0x01 << i));
        }
    }
}
/****
	*@brief 主机接收一位数据
	*@parameter 无
	*@ReturnValue i：18B20返回0或1；
	*/
uint8_t DS18B20_ReceiveBit(void)
{
    uint8_t i = 0;
    if(DS18B20_ExistSign == 1) //存在18B20
    {
        GPIO_WriteBit(DS18B20_Port, DS18B20_Pin, Bit_RESET); //拉低总线
        Delay_us(5);//DS18B20读时序之前，主机要先将总线拉低，表示开始读取
        GPIO_WriteBit(DS18B20_Port, DS18B20_Pin, Bit_SET); //释放总线，控制权交给从机
        Delay_us(10);//从机将在下降沿产生之后的15us左右返回数据
        i = GPIO_ReadInputDataBit(DS18B20_Port, DS18B20_Pin); //读取数据
        GPIO_WriteBit(DS18B20_Port, DS18B20_Pin, Bit_SET); //释放总线
        Delay_us(45);
    }
    return i;
}

/****
	*@brief 主机接收一字节数据
	*@parameter 无
	*@ReturnValue Data：DS18B20返回的数据
	*/
uint8_t DS18B20_ReceiveData(void)
{
    uint8_t i = 0, Data = 0;
    if(DS18B20_ExistSign == 1) //存在18B20
    {
        for(i = 0; i < 8; i++)
        {
            if(DS18B20_ReceiveBit())
            {
                Data |= (0x01 << i);
            }
        }
    }
    return Data;
}
/****
	*@brief 刷新DS18B20暂存器中的数据
	*@parameter 无
	*@ReturnValue 无
	*/
void DS18B20_ConvertTem(void)
{
    DS18B20_Reset();
    if(DS18B20_ExistSign == 1) //存在18B20
    {
        DS18B20_SendData(DS18B20_SKIP_ROM);
        DS18B20_SendData(DS18B20_CONVERT_T);
    }
}
/****
	*@brief 获取DS18B20原始数据
	*@parameter 无
	*@ReturnValue 无
	*/
void DS18B20_GetData(void)
{
    uint8_t i;
    DS18B20_Reset();
    if(DS18B20_ExistSign == 1) //存在18B20
    {
        DS18B20_SendData(DS18B20_SKIP_ROM);
        DS18B20_SendData(DS18B20_READ_SCRATCHPAD);
        for(i = 0; i < 9; i++)
        {
            TemData[i] = DS18B20_ReceiveData();
        }
    }
}

/****
	*@brief 温度数据处理函数
	*@parameter 无
	*@ReturnValue 无
	*/
void DS18B20_TemProcess(void)
{
    float float_temp;
    float_temp = ((int16_t )((TemData[1] << 8) | TemData[0])) / 16.0; //必须将((TemData[1]<<8)|TemData[0]))强制类型转换为16位有符号类型
    DS18B20_FloatTemData = float_temp;
    if(float_temp < 0) //符号位为1，温度为负
    {
        float_temp = -float_temp;
        DS18B20_Tem_Sign = 1; //温度为负标志位
    }
    else
    {
        DS18B20_Tem_Sign = 0; //温度为正标志位
    }
    DS18B20_Tem_Integer = (int16_t)float_temp;
    DS18B20_Tem_Decimal = (uint8_t)(float_temp * 10.0) % 10;
}


float DS18B20_ReturnTem(void)//DS18B20返回浮点类型温度数据
{
    return DS18B20_FloatTemData;
}

uint8_t DS18B20_ReturnTemInteger(void)//DS18B20只返回温度数据整数部分
{
    return DS18B20_Tem_Integer;
}

uint8_t DS18B20_ReturnTemDecimal(void)//DS18B20只返回温度小数部分（小数点后一位的数字）
{
	return DS18B20_Tem_Decimal;
}


uint8_t DS18B20_FlagExist(void)//DS18B20返回存在标志
{
	return DS18B20_ExistSign;
}
uint8_t DS18B20_FlagTem(void)//DS18B20返回温度正负标志
{
	return DS18B20_Tem_Sign;
}



