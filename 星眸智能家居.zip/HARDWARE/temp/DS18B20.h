#ifndef __DS18B20_H
#define __DS18B20_H


void DS18B20_PinInit(void);//初始化DS18B20数据引脚
void DS18B20_Reset(void);//复位DS18B20
uint8_t DS18B20_ReceiveData(void);//主机接收DS18B20返回的一字节数据
void DS18B20_SendData(uint8_t Data);//主机向DS18B20发送一字节数据
void DS18B20_ConvertTem(void);//18B20开始温度转换
void DS18B20_GetData(void);//获取18B20返回的原始数据
void DS18B20_TemProcess(void);//温度数据处理函数
float DS18B20_ReturnTem(void);//DS18B20返回温度数据
uint8_t DS18B20_FlagExist(void);//DS18B20返回是否存在标志位,存在返回1
uint8_t DS18B20_FlagTem(void);//返回温度正负标志位
uint8_t DS18B20_ReturnTemDecimal(void);//DS18B20只返回温度小数部分（小数点后一位的数字）
uint8_t DS18B20_ReturnTemInteger(void);//DS18B20只返回温度数据整数部分
void DS18B20_WriteScratchPad(int8_t TH, int8_t TL,uint8_t Configure,uint8_t DS18B20_Set);
void DS18B20_DefaultSet(void);//18B20恢复默认精度设置
void DS18B20_GetRom(void);//获取18B20Rom信息
void DS18B20Group_ScanDevice(void);//扫描总线上的DS18B20数量
uint8_t DS18B20Group_ReturnDeviceloaction(void);//返回总线上18B20的数量
void DS18B20Group_GetData(uint8_t location);//总线上多个18B20时获取温度
void DS18B20Group_ConvertTem(uint8_t location);//总线上多个18B20时开始温度转换
uint8_t DS18B20Group_ReturnAccuracy(uint8_t location);//返回18B20精度信息
void DS18B20Group_WriteScratchPad(uint8_t Location,int8_t TH, int8_t TL,uint8_t Configure,uint8_t DS18B20_Set);//修改指定Rom的18B20配置信息

#endif













