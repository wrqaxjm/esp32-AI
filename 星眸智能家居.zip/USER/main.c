#include "stm32f10x.h"                  // Device header
#include "Oled.h"
#include "Delay.h"
#include "DS18B20.h"
#include "adc.h"
#include "usart.h"
#include "timer.h"
#include "beep.h"
#include "led.h"
//����Э���
#include "onenet.h"
//�����豸
#include "esp8266.h"
//C��
#include <string.h>
#include <stdio.h>
#include <math.h> // ������ѧ������ͷ�ļ�


int Beep, LED;
float Tempture, smoke_voltage, light_sensor_float;
 int light_sensor;
void Hardware_Init(void) {
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);    //�жϿ�������������
    Usart1_Init(115200);                            //����1����ӡ��Ϣ��
    Usart2_Init(115200);                            //����2������ESP8266��
    UsartPrintf(USART_DEBUG, " Hardware init OK\r\n");
    Beep_Init();
    Led_Init();
    TIM3_Int_Init(2499, 7199);
    TIM2_Int_Init(2499, 7199);
    OLED_Init();
    DS18B20_PinInit();
    ADC1_Init();
    ADC2_Init();
    UsartPrintf(USART_DEBUG, " Hardware init OK\r\n");
}

int main(void) {
    char PUB_BUF[256]; //�ϴ����ݵ�
    const char *topicse[] = {"/xinmou_digitalhome/sub"};
    unsigned short timeCount = 0;    //���ͼ������
    unsigned char *dataPtr = NULL;
    Hardware_Init();                //��ʼ����ΧӲ��
    UsartPrintf(USART_DEBUG, " OK\r\n");
    ESP8266_Init();                    //��ʼ��ESP8266
    while (OneNet_DevLink())            //����OneNET
        Delay_ms(500);
    UsartPrintf(USART_DEBUG, " OK\r\n");
    Beep_Set(BEEP_ON);    //������ʾ����ɹ�
    Delay_ms(1000);
    Beep_Set(BEEP_OFF);
    UsartPrintf(USART_DEBUG, " OK\r\n");
    OneNet_Subscribe(topicse, 1);
    UsartPrintf(USART_DEBUG, " OK\r\n");
    while (1) {
        DS18B20_ConvertTem();
        DS18B20_GetData();
        DS18B20_TemProcess();
		
		Tempture = DS18B20_ReturnTem();
        smoke_voltage = Get_ADC1();
        light_sensor_float = Get_ADC2(); // ��ȡ����ǿ�ȵĸ�����ֵ
        light_sensor = (int)light_sensor_float; // ��������ת��Ϊ����
		
        OLED_DisplayFloat(3, 3, smoke_voltage, 4, 4);
        OLED_DisplayFloat(2, 3, Tempture, 4, 4);
        OLED_DisplayFloat(1, 3, light_sensor_float, 4, 4);
		
        
        LED = GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_15);
        Beep = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_3);
		
		
        if (timeCount % 40 == 0) {                                    //���ͼ��1s
            UsartPrintf(USART_DEBUG, "����: %f\r\n", smoke_voltage);
            UsartPrintf(USART_DEBUG, "����ǿ��: %f\r\n", light_sensor_float);
            UsartPrintf(USART_DEBUG, "�¶�: %f\r\n", Tempture);
        }
        if (++timeCount >= 120) {                                    //���ͼ��3s
            UsartPrintf(USART_DEBUG, "OneNet_Publish\r\n");
            sprintf(PUB_BUF, "{\"smoke\":%f,\"Temp\":%f,\"light_sensor\":%d,\"LED\":%d,\"Beep\":%d}", smoke_voltage,
                    Tempture,light_sensor , LED, Beep ? 0 : 1);
            OneNet_Publish("/xinmou_digitalhome/pub", PUB_BUF);
            timeCount = 0;
            ESP8266_Clear();
        }
        dataPtr = ESP8266_GetIPD(3);
        if (dataPtr != NULL)
            OneNet_RevPro(dataPtr);
        Delay_ms(10);
    }
}
